# NAVER API
client_id = 'T3Rd_DJRBOjjgNL6y1_D'
client_secret = 'EijOUBip27'

# PostgreSQL
host = 'lucky.db.elephantsql.com'
user = 'dizwjffo'
password = '9KzkQWrDyEwiUAgqJrSjIlg5tyK7hvaR'
db = 'dizwjffo'